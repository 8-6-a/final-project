# final-project

DEVELOPMENT
* Open CLI window
1. *cd group-project*
2. *npm install* 
3. *npm start*
* Your app will be served on port 8080

PRODUCTION
* To deploy your app to Heroku, complete the following steps:
1. Signup for a free Heroku account at https://www.heroku.com
2. Create a new Heroku app inside the dashboard
3. Once created, select the Github integration option
4. After you've connected to Github, you'll need to select the repo you are connecting to (final-project)
5. Once it has been selected, scroll down to Manual Deploy and click the Deploy button
* After the initial deploy, your team will need to continue to deploy small features as they are completed in development. Do not attempt to deploy several new features at once as it often will result in production issues.

